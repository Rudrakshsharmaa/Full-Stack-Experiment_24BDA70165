require('dotenv').config();

const express = require('express');
const mongoose = require('mongoose');
const path = require('path');

const app = express();

// ======================
// Middleware
// ======================
app.use(express.json());

// Custom Logger Middleware
const logger = require('./middleware/logger');
app.use(logger);

// Serve Frontend
app.use(express.static(path.join(__dirname, 'public')));

// Default Route
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ======================
// Routes
// ======================
app.use('/api', require('./routes/authRoutes'));
app.use('/api', require('./routes/transactionRoutes'));

// ======================
// MongoDB Connection
// ======================
mongoose.connect(process.env.MONGO_URI)
    .then(() => console.log("✅ MongoDB Connected"))
    .catch(err => console.log(err));

// ======================
// Error Handler
// ======================
app.use((err, req, res, next) => {
    console.error(err.message);
    res.status(500).json({ message: "Internal Server Error" });
});

// ======================
// Start Server
// ======================
app.listen(process.env.PORT, () => {
    console.log(`🚀 Server running on http://localhost:${process.env.PORT}`);
});