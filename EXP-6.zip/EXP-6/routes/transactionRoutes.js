const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');

const User = require('../models/User');
const Transaction = require('../models/Transaction');
const auth = require('../middleware/auth');

// Transfer with rollback
router.post('/transfer', auth, async (req, res) => {
    const session = await mongoose.startSession();
    session.startTransaction();

    try {
        const { toUserId, amount } = req.body;

        const from = await User.findById(req.user.id).session(session);
        const to = await User.findById(toUserId).session(session);

        if (from.balance < amount) throw new Error("Insufficient balance");

        from.balance -= amount;
        to.balance += amount;

        await from.save({ session });
        await to.save({ session });

        await Transaction.create([{
            from: from._id,
            to: to._id,
            amount,
            status: "SUCCESS"
        }], { session });

        await session.commitTransaction();
        res.json({ message: "Transfer Success" });

    } catch (err) {
        await session.abortTransaction();
        res.status(400).json({ message: err.message });
    }

    session.endSession();
});

// Logs
router.get('/transactions', auth, async (req, res) => {
    const logs = await Transaction.find({
        $or: [{ from: req.user.id }, { to: req.user.id }]
    });

    res.json(logs);
});

module.exports = router;