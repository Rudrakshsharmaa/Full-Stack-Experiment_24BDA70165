const API = "http://localhost:3000/api";

// ======================
// Register
// ======================
async function register() {
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    const res = await fetch(`${API}/register`, {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({ name, email, password })
    });

    const data = await res.json();
    alert(data.message);
    window.location.href = "index.html";
}

// ======================
// Login
// ======================
async function login() {
    const email = document.getElementById("loginEmail").value;
    const password = document.getElementById("loginPassword").value;

    const res = await fetch(`${API}/login`, {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({ email, password })
    });

    const data = await res.json();

    if (data.accessToken) {
        localStorage.setItem("token", data.accessToken);
        window.location.href = "dashboard.html";
    } else {
        alert(data.message);
    }
}

// ======================
// Get Account
// ======================
async function getAccount() {
    const token = localStorage.getItem("token");

    const res = await fetch(`${API}/account`, {
        headers: { Authorization: token }
    });

    const data = await res.json();

    document.getElementById("account").innerText =
        `Name: ${data.name} | Balance: ₹${data.balance}`;
}

// ======================
// Transfer Money
// ======================
async function transfer() {
    const token = localStorage.getItem("token");
    const toUserId = document.getElementById("toUserId").value;
    const amount = document.getElementById("amount").value;

    const res = await fetch(`${API}/transfer`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            Authorization: token
        },
        body: JSON.stringify({ toUserId, amount })
    });

    const data = await res.json();
    alert(data.message);
}

// ======================
// Get Transactions
// ======================
async function getTransactions() {
    const token = localStorage.getItem("token");

    const res = await fetch(`${API}/transactions`, {
        headers: { Authorization: token }
    });

    const data = await res.json();

    const list = document.getElementById("transactions");
    list.innerHTML = "";

    data.forEach(tx => {
        const li = document.createElement("li");
        li.innerText = `₹${tx.amount} → ${tx.status}`;
        list.appendChild(li);
    });
}

// ======================
// Logout
// ======================
function logout() {
    localStorage.removeItem("token");
    window.location.href = "index.html";
}